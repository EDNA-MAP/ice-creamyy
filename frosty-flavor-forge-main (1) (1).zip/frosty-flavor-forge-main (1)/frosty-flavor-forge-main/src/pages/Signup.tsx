
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Link, useNavigate } from "react-router-dom";
import { UserPlus } from "lucide-react";

const Signup = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const navigate = useNavigate();

  // This handler should call your backend API
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Replace with your API call and handle logic
    alert("Signup feature not connected to backend yet!");
    // On success, redirect or set auth state.
    // navigate("/login");
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center relative bg-cover bg-center"
      style={{
        backgroundImage: 'url("https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1470&q=80")',
      }}
    >
      <div className="absolute inset-0 bg-black/50 z-0" />
      <div className="w-full max-w-md bg-white/90 dark:bg-gray-900/75 rounded-xl shadow-lg p-8 border border-gray-100 backdrop-blur-sm relative z-10">
        <div className="flex flex-col items-center mb-6">
          <UserPlus className="h-10 w-10 text-primary mb-2" />
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Create your Frosty Delights account</h2>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            type="text"
            placeholder="Username"
            required
            value={username}
            onChange={e => setUsername(e.target.value)}
          />
          <Input
            type="email"
            placeholder="Email address"
            required
            value={email}
            onChange={e => setEmail(e.target.value)}
          />
          <Input
            type="password"
            placeholder="Password"
            required
            minLength={6}
            value={password}
            onChange={e => setPassword(e.target.value)}
          />
          <Button className="w-full mt-2" type="submit">Sign Up</Button>
        </form>
        <div className="mt-4 text-sm text-center text-gray-800 dark:text-gray-300">
          Already have an account?{" "}
          <Link to="/login" className="text-primary underline hover:text-primary/90">
            Sign in
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Signup;
