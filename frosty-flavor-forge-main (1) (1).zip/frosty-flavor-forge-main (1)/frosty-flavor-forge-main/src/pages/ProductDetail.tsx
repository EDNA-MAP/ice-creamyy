
import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { Product, getProductById } from "@/data/products";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useCart } from "@/contexts/CartContext";
import RecommendationSection from "@/components/RecommendationSection";
import { ChevronLeft, Minus, Plus, ShoppingCart } from "lucide-react";

const ProductDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(true);
  const { addToCart } = useCart();
  
  useEffect(() => {
    if (!id) return;
    
    const fetchProduct = () => {
      const productData = getProductById(id);
      
      if (productData) {
        setProduct(productData);
      }
      
      setLoading(false);
    };
    
    fetchProduct();
  }, [id]);
  
  const handleAddToCart = () => {
    if (product) {
      addToCart(product, quantity);
    }
  };
  
  const increaseQuantity = () => {
    setQuantity(prev => prev + 1);
  };
  
  const decreaseQuantity = () => {
    setQuantity(prev => (prev > 1 ? prev - 1 : 1));
  };
  
  if (loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow flex items-center justify-center">
          <div className="animate-pulse flex space-x-2">
            <div className="h-3 w-3 bg-primary rounded-full"></div>
            <div className="h-3 w-3 bg-primary rounded-full"></div>
            <div className="h-3 w-3 bg-primary rounded-full"></div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }
  
  if (!product) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow container mx-auto px-4 py-12 text-center">
          <h1 className="text-3xl font-bold mb-4">Product Not Found</h1>
          <p className="mb-8">We couldn't find the product you were looking for.</p>
          <Link to="/products">
            <Button>Back to Products</Button>
          </Link>
        </main>
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow py-12">
        <div className="container mx-auto px-4">
          {/* Breadcrumb */}
          <div className="mb-6">
            <Link to="/products" className="text-gray-600 hover:text-primary flex items-center">
              <ChevronLeft className="h-4 w-4 mr-1" />
              Back to Products
            </Link>
          </div>
          
          {/* Product Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {/* Product Image */}
            <div className="relative">
              <img 
                src={product.image} 
                alt={product.name} 
                className="w-full rounded-lg shadow-lg"
              />
              {product.popular && (
                <div className="absolute top-4 left-4 bg-primary text-white py-1 px-3 rounded-full">
                  Popular
                </div>
              )}
            </div>
            
            {/* Product Info */}
            <div>
              <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
              <p className="text-2xl font-bold text-primary mb-4">
                ${product.price.toFixed(2)}
              </p>
              
              <p className="text-gray-700 mb-6">{product.description}</p>
              
              <div className="mb-6">
                <h3 className="text-lg font-medium mb-2">Product Details</h3>
                <Separator className="my-4" />
                
                <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                  <div className="text-gray-600">Category:</div>
                  <div>{product.category}</div>
                  
                  {product.flavors && (
                    <>
                      <div className="text-gray-600">Flavors:</div>
                      <div>{product.flavors.join(", ")}</div>
                    </>
                  )}
                  
                  {product.allergens && product.allergens.length > 0 && (
                    <>
                      <div className="text-gray-600">Allergens:</div>
                      <div>{product.allergens.join(", ")}</div>
                    </>
                  )}
                  
                  {product.nutritionalInfo && (
                    <>
                      <div className="text-gray-600">Calories:</div>
                      <div>{product.nutritionalInfo.calories} kcal</div>
                      
                      <div className="text-gray-600">Fat:</div>
                      <div>{product.nutritionalInfo.fat}g</div>
                      
                      <div className="text-gray-600">Sugar:</div>
                      <div>{product.nutritionalInfo.sugar}g</div>
                    </>
                  )}
                </div>
              </div>
              
              {/* Quantity Selector */}
              <div className="flex items-center mb-6">
                <span className="mr-4 text-gray-700">Quantity:</span>
                <div className="flex items-center">
                  <Button 
                    variant="outline" 
                    size="icon" 
                    onClick={decreaseQuantity}
                    disabled={quantity <= 1}
                    className="h-10 w-10"
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  
                  <span className="mx-4 font-medium w-8 text-center">{quantity}</span>
                  
                  <Button 
                    variant="outline" 
                    size="icon" 
                    onClick={increaseQuantity}
                    className="h-10 w-10"
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              {/* Add to Cart Button */}
              <Button 
                onClick={handleAddToCart} 
                className="w-full md:w-auto flex items-center justify-center"
                size="lg"
              >
                <ShoppingCart className="mr-2 h-5 w-5" />
                Add to Cart
              </Button>
            </div>
          </div>
          
          {/* AI-powered Recommendations */}
          {id && <RecommendationSection productId={id} />}
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default ProductDetail;
