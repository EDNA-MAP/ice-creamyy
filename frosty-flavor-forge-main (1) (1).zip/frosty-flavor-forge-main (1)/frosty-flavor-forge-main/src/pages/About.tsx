
import React from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Separator } from "@/components/ui/separator";
import { IceCreamCone, CakeSlice, Dessert } from "lucide-react";

const About = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-primary text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Story</h1>
            <p className="max-w-2xl mx-auto text-lg">
              Passionate about ice cream, dedicated to quality, and committed to bringing joy
              with every scoop since 2025.
            </p>
          </div>
        </section>
        
        {/* Mission Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-3xl font-bold mb-6 text-center">Our Mission</h2>
              <p className="text-lg text-gray-700 mb-6">
                At Frosty Delights, we believe that ice cream is more than just a dessert—it's an experience that brings people together and creates lasting memories. Our mission is to craft the most delicious ice cream using only premium, natural ingredients, with flavors that inspire joy and wonder.
              </p>
              <p className="text-lg text-gray-700">
                We're committed to sustainability and ethical sourcing, working directly with local farmers whenever possible to ensure that our ingredients are not only delicious but also responsibly produced.
              </p>
            </div>
          </div>
        </section>
        
        <Separator />
        
        {/* Our Values */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-12 text-center">Our Values</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="rounded-full bg-icecream-pink w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <IceCreamCone className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3">Quality</h3>
                <p className="text-gray-600">
                  We never compromise on quality. From sourcing the finest ingredients to our meticulous production process, excellence is our standard.
                </p>
              </div>
              
              <div className="text-center">
                <div className="rounded-full bg-icecream-mint w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <CakeSlice className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3">Creativity</h3>
                <p className="text-gray-600">
                  We love experimenting with unique flavor combinations, textures, and presentations to create ice cream experiences that surprise and delight.
                </p>
              </div>
              
              <div className="text-center">
                <div className="rounded-full bg-icecream-blue w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Dessert className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3">Community</h3>
                <p className="text-gray-600">
                  We believe in building strong relationships with our customers, suppliers, and the communities we serve, creating positive impact beyond our shops.
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Our Process */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold mb-8 text-center">Our Artisanal Process</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-16">
                <div>
                  <h3 className="text-xl font-bold mb-3">1. Sourcing Premium Ingredients</h3>
                  <p className="text-gray-700 mb-4">
                    We start by carefully selecting the finest ingredients - from local dairy farms for our cream and milk to Madagascar for our vanilla beans. Quality begins at the source.
                  </p>
                  <p className="text-gray-700">
                    Our team works directly with farmers and suppliers who share our values of sustainability and ethical production.
                  </p>
                </div>
                <div className="rounded-lg overflow-hidden shadow-lg">
                  <img 
                    src="https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80" 
                    alt="Fresh ingredients" 
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-16 md:flex-row-reverse">
                <div className="order-2 md:order-1">
                  <h3 className="text-xl font-bold mb-3">2. Small Batch Production</h3>
                  <p className="text-gray-700 mb-4">
                    Each batch of our ice cream is made in small quantities to ensure perfect texture and flavor. This artisanal approach means more attention to detail and higher quality.
                  </p>
                  <p className="text-gray-700">
                    Our ice cream makers are trained extensively and bring years of experience to their craft, treating each batch like a work of art.
                  </p>
                </div>
                <div className="order-1 md:order-2 rounded-lg overflow-hidden shadow-lg">
                  <img 
                    src="https://images.unsplash.com/photo-1579954115545-a95591f28bfc?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80" 
                    alt="Ice cream making process" 
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                <div>
                  <h3 className="text-xl font-bold mb-3">3. Innovation & Tradition</h3>
                  <p className="text-gray-700 mb-4">
                    We honor classic ice cream making traditions while embracing innovation. Our flavor lab is where we experiment with new combinations and techniques.
                  </p>
                  <p className="text-gray-700">
                    Every new flavor undergoes extensive testing and tasting before it makes it to our menu, ensuring it meets our high standards.
                  </p>
                </div>
                <div className="rounded-lg overflow-hidden shadow-lg">
                  <img 
                    src="https://images.unsplash.com/photo-1505394033641-40c6ad1178d7?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80" 
                    alt="Ice cream varieties" 
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Team Section */}
        <section className="py-16 bg-icecream-blue/20">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-12 text-center">Meet Our Team</h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="rounded-full overflow-hidden w-40 h-40 mx-auto mb-4">
                  <img 
                    src="omy.jpg" 
                    alt="Team member" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-lg font-bold mb-1">Edna Maphupha</h3>
                <p className="text-primary font-medium mb-2">Developer</p>
                <p className="text-gray-600 text-sm">
                 Software Developer with great skills.
                </p>
              </div>
              
            
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default About;
