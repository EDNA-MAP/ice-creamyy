
import { Suspense } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { IceCreamCone, CakeSlice, Dessert } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import FeaturedProducts from "@/components/FeaturedProducts";
import { getPopularProducts } from "@/data/products";
import ProductCard from "@/components/ProductCard";

const Index = () => {
  const popularProducts = getPopularProducts().slice(0, 4);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="hero-pattern relative bg-gradient-to-br from-white to-icecream-pink py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/2 mb-10 md:mb-0">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
                  <span className="text-primary">Handcrafted</span> Ice Cream
                  <br /> For Every <span className="text-primary">Moment</span>
                </h1>
                <p className="text-lg md:text-xl mb-8 text-gray-700 max-w-lg">
                  Experience the creamiest texture and most vibrant flavors made with premium ingredients and lots of love.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Link to="/products">
                    <Button size="lg" className="w-full sm:w-auto">
                      Shop Now
                    </Button>
                  </Link>
                  <Link to="/about">
                    <Button variant="outline" size="lg" className="w-full sm:w-auto">
                      Our Story
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="md:w-1/2 flex justify-center">
                <div className="relative">
                  <img
                    src="https://images.unsplash.com/photo-1629385701021-cb8e14559990?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80"
                    alt="Ice cream cone with berries"
                    className="rounded-lg shadow-2xl max-w-md"
                  />
                  <div className="absolute -bottom-6 -right-6 bg-white p-4 rounded-lg shadow-lg animate-float">
                    <div className="flex items-center gap-2">
                      <IceCreamCone className="text-primary h-6 w-6" />
                      <span className="font-bold">100% Natural Ingredients</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Featured Products Carousel */}
        <Suspense fallback={<div>Loading...</div>}>
          <FeaturedProducts />
        </Suspense>

        {/* Popular Products Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold mb-4">Customer Favorites</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Our most loved flavors, crafted with the finest ingredients and a dash of magic.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {popularProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>

            <div className="text-center mt-10">
              <Link to="/products">
                <Button variant="outline" size="lg">
                  View All Flavors
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Why Choose Frosty Delights?</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                We're passionate about creating memorable ice cream experiences with quality, creativity, and care.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="border-none shadow-md">
                <CardContent className="pt-6">
                  <div className="rounded-full bg-primary/10 w-12 h-12 flex items-center justify-center mb-4 mx-auto">
                    <IceCreamCone className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold text-center mb-2">Premium Ingredients</h3>
                  <p className="text-gray-600 text-center">
                    Only the finest natural ingredients go into our ice cream, sourced from local farmers whenever possible.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-none shadow-md">
                <CardContent className="pt-6">
                  <div className="rounded-full bg-primary/10 w-12 h-12 flex items-center justify-center mb-4 mx-auto">
                    <CakeSlice className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold text-center mb-2">Handcrafted Daily</h3>
                  <p className="text-gray-600 text-center">
                    Every batch of our ice cream is made fresh daily in small batches for the perfect texture and flavor.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-none shadow-md">
                <CardContent className="pt-6">
                  <div className="rounded-full bg-primary/10 w-12 h-12 flex items-center justify-center mb-4 mx-auto">
                    <Dessert className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold text-center mb-2">Unique Flavors</h3>
                  <p className="text-gray-600 text-center">
                    Our flavor experts create unique combinations that will surprise and delight your taste buds.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Newsletter Section */}
        <section className="py-16 bg-gradient-to-r from-icecream-blue to-icecream-mint">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl font-bold mb-4">Stay Cool with Updates</h2>
              <p className="text-gray-700 mb-8">
                Subscribe to our newsletter for new flavor announcements, special offers, and ice cream inspiration.
              </p>
              <form className="flex flex-col sm:flex-row gap-2">
                <input
                  type="email"
                  placeholder="Your email address"
                  className="flex-grow px-4 py-3 rounded-lg border"
                />
                <Button type="submit" className="whitespace-nowrap">
                  Subscribe
                </Button>
              </form>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Index;
