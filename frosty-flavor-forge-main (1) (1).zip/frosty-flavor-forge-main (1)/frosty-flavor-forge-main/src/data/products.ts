
export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  featured: boolean;
  popular: boolean;
  flavors?: string[];
  allergens?: string[];
  nutritionalInfo?: {
    calories: number;
    fat: number;
    sugar: number;
  };
}

export const products: Product[] = [
  {
    id: "1",
    name: "Classic Vanilla Bean",
    description: "Smooth and creamy vanilla ice cream made with real Madagascar vanilla beans.",
    price: 14.99,
    image: "https://www.bing.com/images/search?view=detailV2&ccid=HebjLXrU&id=0657CE2ACDA0C942FD745CF29ACB494138676042&thid=OIP.HebjLXrU-u4qEaqMwOzOxQHaLH&mediaurl=https%3A%2F%2Fmildlymeandering.com%2Fwp-content%2Fuploads%2F2021%2F02%2F01-No-Churn-Vanilla-Ice-Cream.jpg&cdnurl=https%3A%2F%2Fth.bing.com%2Fth%2Fid%2FR.1de6e32d7ad4faee2a11aa8cc0eccec5%3Frik%3DQmBnOEFJy5ryXA%26pid%3DImgRaw%26r%3D0&exph=1021&expw=680&q=classic+vanilla+bean&simid=608054575758857792&form=IRPRST&ck=AEE66BC231ED08418B222364459938B0&selectedindex=2&itb=0&ajaxhist=0&ajaxserp=0&pivotparams=insightsToken%3Dccid_WbqDOmtp*cp_61BBADE74AC9944242D594D0F5E77124*mid_035DCF7360651B0DDB2335130A9D04D44429841E*simid_608016419261738661*thid_OIP.WbqDOmtppZv-1mNSHs0D7AHaLH&vt=0&sim=11&iss=VSI&ajaxhist=0&ajaxserp=0",
    category: "Classic",
    featured: true,
    popular: true,
    flavors: ["vanilla"],
    allergens: ["milk", "eggs"],
    nutritionalInfo: {
      calories: 250,
      fat: 14,
      sugar: 20,
    },
  },
  {
    id: "2",
    name: "Double Chocolate Fudge",
    description: "Rich chocolate ice cream with chunks of fudge brownies and a chocolate swirl.",
    price: 8.99,
    image: "https://images.unsplash.com/photo-1563805042-7684c019e1cb?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80",
    category: "Chocolate",
    featured: true,
    popular: true,
    flavors: ["chocolate"],
    allergens: ["milk", "eggs", "wheat", "soy"],
    nutritionalInfo: {
      calories: 320,
      fat: 18,
      sugar: 32,
    },
  },
  {
    id: "3",
    name: "Strawberry Fields",
    description: "Creamy strawberry ice cream made with fresh strawberries and a hint of lemon.",
    price: 11.99,
    image: "https://www.bing.com/images/search?view=detailV2&ccid=a3kJA5oR&id=BA2696A151C66384EE2F1290C7F62ED0F77680AB&thid=OIP.a3kJA5oRc9pdCBfpMk6TcgHaEg&mediaurl=https%3a%2f%2frespectful.co.uk%2fapp%2fuploads%2f2022%2f07%2fStrawberryFieldsIceCream-1024x624.png&cdnurl=https%3a%2f%2fth.bing.com%2fth%2fid%2fR.6b7909039a1173da5d0817e9324e9372%3frik%3dq4B299Au9seQEg%26pid%3dImgRaw%26r%3d0&exph=624&expw=1024&q=strawberry+fields+ice+cream&simid=607986126896264942&FORM=IRPRST&ck=9402DCDF37A4DB64B48B8A48B989152F&selectedIndex=1&itb=0&ajaxhist=0&ajaxserp=0",
    category: "Fruit",
    featured: false,
    popular: true,
    flavors: ["strawberry", "lemon"],
    allergens: ["milk"],
    nutritionalInfo: {
      calories: 220,
      fat: 12,
      sugar: 24,
    },
  },
  {
    id: "4",
    name: "Mint Chocolate Chip",
    description: "Cool mint ice cream loaded with chocolate chunks and a chocolate fudge swirl.",
    price: 5.49,
    image: "https://www.bing.com/images/search?view=detailV2&ccid=AQzspNj2&id=6519449F941F9838A765128511DBBB1837878BF2&thid=OIP.AQzspNj2b2siZOpvWmiklwHaHa&mediaurl=https%3A%2F%2Fgimmethatflavor.com%2Fwp-content%2Fuploads%2F2022%2F07%2FMint-Chocolate-Chip-Ice-Cream-Square-2.jpg&cdnurl=https%3A%2F%2Fth.bing.com%2Fth%2Fid%2FR.010ceca4d8f66f6b2264ea6f5a68a497%3Frik%3D8ouHNxi72xGFEg%26pid%3DImgRaw%26r%3D0&exph=1200&expw=1200&q=Mint+Chocolate+Chip&simid=608037146797351565&form=IRPRST&ck=02E9C6508F5490892E3025D3209A602A&selectedindex=0&itb=0&ajaxhist=0&ajaxserp=0&vt=0&sim=11",
    category: "Classic",
    featured: true,
    popular: false,
    flavors: ["mint", "chocolate"],
    allergens: ["milk", "soy"],
    nutritionalInfo: {
      calories: 280,
      fat: 16,
      sugar: 25,
    },
  },
  {
    id: "5",
    name: "Cookie Dough Delight",
    description: "Vanilla ice cream packed with chunks of chocolate chip cookie dough and chocolate chips.",
    price: 8.99,
    image: "https://www.bing.com/images/search?view=detailV2&ccid=sQ0nbvxc&id=B7A3A1B1C6A1F269857FB441E3604B0B6DBCBCE9&thid=OIP.sQ0nbvxctMvGp9MGPsZ5UgHaE7&mediaurl=https%3a%2f%2fwww.savvymamalifestyle.com%2fwp-content%2fuploads%2f2025%2f01%2fcookie-dough-topping-2048x1365.jpg&cdnurl=https%3a%2f%2fth.bing.com%2fth%2fid%2fR.b10d276efc5cb4cbc6a7d3063ec67952%3frik%3d6by8bQtLYONBtA%26pid%3dImgRaw%26r%3d0&exph=1365&expw=2048&q=Cookie+Dough+Delight&simid=608028999231689224&FORM=IRPRST&ck=7872AA3737684965DF5A3048FC43D38B&selectedIndex=3&itb=0&ajaxhist=0&ajaxserp=0",
    category: "Premium",
    featured: true,
    popular: true,
    flavors: ["vanilla", "cookie dough"],
    allergens: ["milk", "eggs", "wheat", "soy"],
    nutritionalInfo: {
      calories: 340,
      fat: 18,
      sugar: 35,
    },
  },
  {
    id: "6",
    name: "Salted Caramel Swirl",
    description: "Buttery caramel ice cream with a salted caramel swirl and toffee pieces.",
    price: 10.19,
    image: "https://images.unsplash.com/photo-1579954115545-a95591f28bfc?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80",
    category: "Premium",
    featured: false,
    popular: true,
    flavors: ["caramel"],
    allergens: ["milk", "soy"],
    nutritionalInfo: {
      calories: 310,
      fat: 17,
      sugar: 32,
    },
  },
  {
    id: "7",
    name: "Mango Tango Sorbet",
    description: "Refreshing dairy-free mango sorbet with a hint of lime. Perfect for hot days!",
    price: 7.99,
    image: "https://www.bing.com/images/search?view=detailV2&ccid=P03Do5TR&id=DA4B69AB0E98CA433DDA563434D1110F34A3175B&thid=OIP.P03Do5TRlqa6MpVxXMEvsQHaHa&mediaurl=https%3a%2f%2fwww.tasteofhome.com%2fwp-content%2fuploads%2f0001%2f01%2fQuick-Mango-Passion-Fruit-Sorbet_EXPS_TOHFM20_238674_B09_20_3b.jpg&cdnurl=https%3a%2f%2fth.bing.com%2fth%2fid%2fR.3f4dc3a394d196a6ba3295715cc12fb1%3frik%3dWxejNA8R0TQ0Vg%26pid%3dImgRaw%26r%3d0&exph=1200&expw=1200&q=mango+tango+sorbet&simid=608018605356907506&FORM=IRPRST&ck=31DB012073AE6F2A96247EE123BDFB5D&selectedIndex=11&itb=0&ajaxhist=0&ajaxserp=0",
    category: "Sorbet",
    featured: false,
    popular: false,
    flavors: ["mango", "lime"],
    allergens: [],
    nutritionalInfo: {
      calories: 150,
      fat: 0,
      sugar: 32,
    },
  },
  {
    id: "8",
    name: "Pistachio Dream",
    description: "Creamy pistachio ice cream made with real pistachios and a hint of almond.",
    price: 5.99,
    image: "https://images.unsplash.com/photo-1521305916504-4a1121188589?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80",
    category: "Nuts",
    featured: false,
    popular: false,
    flavors: ["pistachio", "almond"],
    allergens: ["milk", "nuts"],
    nutritionalInfo: {
      calories: 290,
      fat: 19,
      sugar: 22,
    },
  },
];

export const categories = [
  "All",
  "Classic",
  "Chocolate",
  "Fruit",
  "Nuts",
  "Premium",
  "Sorbet"
];

export const getFeaturedProducts = (): Product[] => {
  return products.filter(product => product.featured);
};

export const getPopularProducts = (): Product[] => {
  return products.filter(product => product.popular);
};

export const getProductsByCategory = (category: string): Product[] => {
  if (category === "All") return products;
  return products.filter(product => product.category === category);
};

export const getProductById = (id: string): Product | undefined => {
  return products.find(product => product.id === id);
};

export const getRelatedProducts = (id: string, limit: number = 4): Product[] => {
  const currentProduct = getProductById(id);
  if (!currentProduct) return [];
  
  return products
    .filter(product => 
      product.id !== id && 
      (product.category === currentProduct.category || 
       product.flavors?.some(flavor => 
         currentProduct.flavors?.includes(flavor)
       ))
    )
    .slice(0, limit);
};

export const getRecommendedProducts = (id: string, limit: number = 4): Product[] => {
  // This is a mock of what would normally come from a TensorFlow recommendation model
  // In a real implementation, this would call an API that returns products based on ML model
  const currentProduct = getProductById(id);
  if (!currentProduct) return getPopularProducts().slice(0, limit);
  
  // Logic to simulate a recommendation algorithm
  const similarityScore = new Map<string, number>();
  
  products.forEach(product => {
    if (product.id === id) return; // Skip the current product
    
    let score = 0;
    
    // Category match
    if (product.category === currentProduct.category) score += 3;
    
    // Flavor overlaps
    const flavorOverlap = product.flavors?.filter(flavor => 
      currentProduct.flavors?.includes(flavor)
    ).length || 0;
    score += flavorOverlap * 2;
    
    // Popular items get a boost
    if (product.popular) score += 1;
    
    // Price similarity (closer prices get higher scores)
    const priceDiff = Math.abs(product.price - currentProduct.price);
    if (priceDiff < 1) score += 1;
    
    similarityScore.set(product.id, score);
  });
  
  // Sort by score and return top results
  return products
    .filter(product => product.id !== id)
    .sort((a, b) => 
      (similarityScore.get(b.id) || 0) - (similarityScore.get(a.id) || 0)
    )
    .slice(0, limit);
};
