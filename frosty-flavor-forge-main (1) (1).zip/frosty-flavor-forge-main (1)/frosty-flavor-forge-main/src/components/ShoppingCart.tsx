
import { useCart } from "@/contexts/CartContext";
import { Button } from "@/components/ui/button";
import { Minus, Plus, ShoppingCart, X, Trash2 } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";

const ShoppingCartComponent = () => {
  const { 
    items, 
    removeFromCart, 
    updateQuantity, 
    clearCart, 
    totalItems, 
    totalPrice,
    isCartOpen,
    setIsCartOpen
  } = useCart();

  return (
    <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
      <SheetContent className="w-full sm:max-w-md overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="flex items-center">
            <ShoppingCart className="mr-2 h-5 w-5" />
            Your Cart
            <span className="ml-2 text-sm font-normal text-gray-500">
              ({totalItems} {totalItems === 1 ? 'item' : 'items'})
            </span>
          </SheetTitle>
        </SheetHeader>
        
        {items.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-80">
            <ShoppingCart className="h-16 w-16 text-gray-300 mb-4" />
            <p className="text-gray-500 mb-6">Your cart is empty</p>
            <Button variant="default" onClick={() => setIsCartOpen(false)}>
              Continue Shopping
            </Button>
          </div>
        ) : (
          <div className="flex flex-col h-full">
            <div className="flex-grow overflow-auto py-4">
              {items.map((item) => (
                <div key={item.product.id} className="flex py-4 border-b">
                  <div className="h-20 w-20 rounded-md overflow-hidden">
                    <img 
                      src={item.product.image}
                      alt={item.product.name}
                      className="h-full w-full object-cover"
                    />
                  </div>
                  
                  <div className="ml-4 flex-grow">
                    <p className="font-medium">{item.product.name}</p>
                    <p className="text-sm text-gray-500">${item.product.price.toFixed(2)}</p>
                    
                    <div className="flex items-center mt-2">
                      <Button 
                        variant="outline" 
                        size="icon" 
                        className="h-8 w-8" 
                        onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                      >
                        <Minus className="h-3 w-3" />
                      </Button>
                      
                      <span className="mx-3 w-8 text-center">
                        {item.quantity}
                      </span>
                      
                      <Button 
                        variant="outline" 
                        size="icon" 
                        className="h-8 w-8" 
                        onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                      
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 ml-auto text-gray-500 hover:text-red-500" 
                        onClick={() => removeFromCart(item.product.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-4 space-y-4">
              <Separator />
              
              <div className="flex items-center justify-between py-2">
                <span>Subtotal</span>
                <span className="font-bold">${totalPrice.toFixed(2)}</span>
              </div>
              
              <div className="flex items-center justify-between py-2 text-sm text-gray-500">
                <span>Taxes & Shipping calculated at checkout</span>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <Button variant="outline" onClick={() => clearCart()}>
                  Clear Cart
                </Button>
                <Button>Checkout</Button>
              </div>
            </div>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
};

export default ShoppingCartComponent;
