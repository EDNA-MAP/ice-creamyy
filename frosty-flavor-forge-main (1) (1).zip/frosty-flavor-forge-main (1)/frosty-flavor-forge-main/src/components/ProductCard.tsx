
import { Product } from "@/data/products";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useCart } from "@/contexts/CartContext";
import { IceCreamCone } from "lucide-react";

interface ProductCardProps {
  product: Product;
  featured?: boolean;
}

const ProductCard = ({ product, featured = false }: ProductCardProps) => {
  const { addToCart } = useCart();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product, 1);
  };

  if (featured) {
    return (
      <Link 
        to={`/product/${product.id}`} 
        className="group relative overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
      >
        <div className="relative h-80 overflow-hidden">
          <img 
            src={product.image} 
            alt={product.name} 
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
          <div className="absolute bottom-0 left-0 w-full p-6 text-white">
            <h3 className="text-xl md:text-2xl font-bold mb-2">{product.name}</h3>
            <p className="mb-4 text-sm md:text-base opacity-90 line-clamp-2">{product.description}</p>
            <div className="flex items-center justify-between">
              <span className="text-lg md:text-xl font-bold">${product.price.toFixed(2)}</span>
              <Button 
                variant="default" 
                size="sm"
                onClick={handleAddToCart}
                className="bg-white text-primary hover:bg-gray-100"
              >
                Add to Cart
              </Button>
            </div>
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link 
      to={`/product/${product.id}`} 
      className="group bg-white rounded-lg shadow-sm hover:shadow-md transition-all duration-300 flex flex-col h-full overflow-hidden"
    >
      <div className="relative h-48 overflow-hidden">
        <img 
          src={product.image} 
          alt={product.name} 
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        {product.popular && (
          <span className="absolute top-2 left-2 bg-primary text-white text-xs px-2 py-1 rounded-full">
            Popular
          </span>
        )}
      </div>
      <div className="p-4 flex flex-col flex-grow">
        <h3 className="text-lg font-bold mb-1">{product.name}</h3>
        <p className="text-gray-600 text-sm mb-3 line-clamp-2 flex-grow">{product.description}</p>
        <div className="flex items-center justify-between mt-auto">
          <span className="font-bold text-gray-900">${product.price.toFixed(2)}</span>
          <Button 
            variant="outline" 
            size="sm"
            onClick={handleAddToCart}
            className="text-primary hover:bg-primary hover:text-white"
          >
            Add to Cart
          </Button>
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;
