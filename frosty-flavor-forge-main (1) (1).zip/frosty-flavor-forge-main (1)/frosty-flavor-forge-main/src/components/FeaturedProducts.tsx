
import { useState, useEffect } from "react";
import { Product, getFeaturedProducts } from "@/data/products";
import ProductCard from "./ProductCard";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";

const FeaturedProducts = () => {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  
  useEffect(() => {
    setFeaturedProducts(getFeaturedProducts());
  }, []);
  
  const nextSlide = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === featuredProducts.length - 1 ? 0 : prevIndex + 1
    );
  };
  
  const prevSlide = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === 0 ? featuredProducts.length - 1 : prevIndex - 1
    );
  };
  
  // Auto-advance slides
  useEffect(() => {
    const timer = setTimeout(() => {
      nextSlide();
    }, 5000);
    
    return () => clearTimeout(timer);
  }, [currentIndex, featuredProducts.length]);
  
  if (featuredProducts.length === 0) return null;
  
  return (
    <section className="relative bg-gradient-to-r from-icecream-mint to-icecream-blue py-12 overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center">
          {/* Text Content */}
          <div className="lg:w-1/3 mb-8 lg:mb-0 lg:pr-10">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Featured Flavors</h2>
            <p className="text-lg text-gray-700 mb-6">
              Discover our most loved ice cream creations, crafted with premium ingredients and lots of love.
            </p>
            <Link to="/products">
              <Button variant="default" size="lg">
                Explore All Flavors
              </Button>
            </Link>
          </div>
          
          {/* Carousel */}
          <div className="lg:w-2/3 relative">
            <div className="relative overflow-hidden rounded-xl shadow-xl">
              <div 
                className="flex transition-transform duration-500 ease-in-out"
                style={{ transform: `translateX(-${currentIndex * 100}%)` }}
              >
                {featuredProducts.map((product) => (
                  <div key={product.id} className="w-full flex-shrink-0">
                    <ProductCard product={product} featured={true} />
                  </div>
                ))}
              </div>
            </div>
            
            {/* Navigation Controls */}
            <Button 
              variant="secondary" 
              size="icon" 
              className="absolute top-1/2 left-2 transform -translate-y-1/2 rounded-full"
              onClick={prevSlide}
            >
              <ChevronLeft className="h-6 w-6" />
            </Button>
            <Button 
              variant="secondary" 
              size="icon" 
              className="absolute top-1/2 right-2 transform -translate-y-1/2 rounded-full"
              onClick={nextSlide}
            >
              <ChevronRight className="h-6 w-6" />
            </Button>
            
            {/* Indicators */}
            <div className="flex justify-center mt-4 gap-2">
              {featuredProducts.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`h-2 rounded-full transition-all ${
                    currentIndex === index ? "w-8 bg-primary" : "w-2 bg-gray-300"
                  }`}
                  aria-label={`Go to slide ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts;
