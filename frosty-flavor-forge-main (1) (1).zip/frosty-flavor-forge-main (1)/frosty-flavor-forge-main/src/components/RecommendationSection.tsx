
import { useState, useEffect } from "react";
import { Product, getRecommendedProducts } from "@/data/products";
import ProductCard from "./ProductCard";
import { CandyCane } from "lucide-react";

interface RecommendationSectionProps {
  productId: string;
  title?: string;
}

const RecommendationSection = ({ 
  productId,
  title = "You May Also Like"
}: RecommendationSectionProps) => {
  const [recommendations, setRecommendations] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    // Simulate API delay to show loading state (like it would be with a real ML model)
    const timer = setTimeout(() => {
      const recommendedItems = getRecommendedProducts(productId);
      setRecommendations(recommendedItems);
      setLoading(false);
    }, 800);
    
    return () => clearTimeout(timer);
  }, [productId]);
  
  if (loading) {
    return (
      <div className="py-10">
        <h2 className="text-2xl font-bold mb-6 text-center">{title}</h2>
        <div className="flex justify-center items-center h-40">
          <div className="animate-pulse flex space-x-2">
            <div className="h-3 w-3 bg-primary rounded-full"></div>
            <div className="h-3 w-3 bg-primary rounded-full"></div>
            <div className="h-3 w-3 bg-primary rounded-full"></div>
          </div>
        </div>
      </div>
    );
  }
  
  if (recommendations.length === 0) return null;
  
  return (
    <section className="py-10">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-center mb-8">
          <CandyCane className="mr-2 h-6 w-6 text-primary" />
          <h2 className="text-2xl font-bold">{title}</h2>
          <div className="ml-4 text-sm bg-icecream-pink text-primary px-2 py-1 rounded-full">
            AI Powered
          </div>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {recommendations.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
        
        <div className="mt-8 text-center text-gray-500 text-sm">
          <p>Recommendations powered by our AI flavor-matching algorithm</p>
        </div>
      </div>
    </section>
  );
};

export default RecommendationSection;
